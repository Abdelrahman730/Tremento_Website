import React from 'react'
import Axios from "axios";
import { useState } from "react";

export default function Summary() {

  const [totalIngredients, settotalIngredients] = useState("");

  const getTotalingredients = () => {
    Axios.get("http://localhost:3001/ingredients").then((response) => {
      settotalIngredients(response.data[0].Num);
    });
  };

  getTotalingredients()

    return(
      <React.Fragment>
      <div className="slim-body">
        <div className="slim-mainpanel">
        <div className="container">
        <div className="manager-header">
            <div className="slim-pageheader">
              <ol className="breadcrumb slim-breadcrumb">
                <li className="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li className="breadcrumb-item active" aria-current="page">Summary</li>
              </ol>
              <h6 className="slim-pagetitle">Summary</h6>
            </div>
            <a id="contactNavicon"  href="" className="contact-navicon"><i className="icon ion-navicon-round"></i></a>
          </div>
          <div className="manager-wrapper">
            <div className="manager-right">
            <div className="report-summary-header">
            <div>
              <h4 className="tx-inverse mg-b-3">Overall Summary Report</h4>
              <p className="mg-b-0"><i className="icon ion-calendar mg-r-3"></i> January 01, 2018 - January 31, 2018</p>
            </div>
            <div></div>
          </div>

          <div className="row no-gutters dashboard-chart-one">
            <div className="col-md-4 col-lg">
              <div className="card card-total">
                <div>
                  <h1>{totalIngredients}</h1>
                  <p>Total Employee</p>
                </div>
                <div>
                  <div className="tx-24 mg-b-10 tx-center op-5">
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-600"></i>
                    <i className="icon ion-man tx-gray-400"></i>
                    <i className="icon ion-man tx-gray-400"></i>
                    <i className="icon ion-man tx-gray-400"></i>
                    <i className="icon ion-man tx-gray-400"></i>
                  </div>
                  <label>Female (66%)</label>
                  <div className="progress mg-b-10">
                    <div className="progress-bar bg-primary progress-bar-xs wd-65p" role="progressbar" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>

                  <label>Male (34%)</label>
                  <div className="progress">
                    <div className="progress-bar bg-danger progress-bar-xs wd-35p" role="progressbar" aria-valuenow="34" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-lg">
              <div className="card card-total">
                <div>
                  <h1>{totalIngredients}</h1>
                  <p>Total Products</p>
                </div>
                <div>
                  <div className="tx-16 mg-b-15 tx-center op-5">
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-600"></i>
                    <i className="icon ion-cube tx-gray-400"></i>
                    <i className="icon ion-cube tx-gray-400"></i>
                  </div>
                  <label>Digital products (85%)</label>
                  <div className="progress mg-b-10">
                    <div className="progress-bar bg-success progress-bar-xs wd-85p" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>

                  <label>Non-digital products (15%)</label>
                  <div className="progress">
                    <div className="progress-bar bg-warning progress-bar-xs wd-15p" role="progressbar" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 col-lg">
              <div className="card card-total">
                <div>
                  <h1>30</h1>
                  <p>Total Franchise</p>
                </div>
                <div>
                  <div className="tx-22 mg-b-10 tx-center op-5">
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-600"></i>
                    <i className="icon ion-location tx-gray-400"></i>
                    <i className="icon ion-location tx-gray-400"></i>
                    <i className="icon ion-location tx-gray-400"></i>
                  </div>
                  <label>Local (75%)</label>
                  <div className="progress mg-b-10">
                    <div className="progress-bar bg-purple progress-bar-xs wd-75p" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>

                  <label>International (25%)</label>
                  <div className="progress">
                    <div className="progress-bar bg-pink progress-bar-xs wd-25p" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>

        </div>
        </div>
        </div>
        </div>
        </div>
        </div>

        </React.Fragment>
    )
}