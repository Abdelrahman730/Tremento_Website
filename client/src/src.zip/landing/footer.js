import React from 'react';

export default function Error()
{
    return (
    <div className="slim-landing" >
        <div className="slim-landing-footer">
            <div className="container">
            <h1>The Responsive Bootstrap 4 Admin Dashboard Template</h1>
            </div> 
         </div>
        </div>
    )
}